# Albion Online Bot

Android бот с AI-основой для сбора ресурсов в Albion Online.

- Запуск через Accessibility Service
- Сборка через GitHub Actions
- Работает без root на Android 14+
